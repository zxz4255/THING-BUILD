/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2026 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.api.models.marketplace

import com.google.gson.annotations.SerializedName
import net.ccbluex.liquidbounce.config.types.list.Tagged
import net.ccbluex.liquidbounce.features.addon.AddonApi
import net.ccbluex.liquidbounce.features.addon.AddonInstaller
import net.ccbluex.liquidbounce.features.marketplace.MarketplaceManager
import net.ccbluex.liquidbounce.integration.theme.ThemeManager

@AddonApi
enum class MarketplaceItemType(
    override val tag: String,
    val isListable: Boolean,
    val isSubscribable: Boolean
) : Tagged {
    @SerializedName("Config")
    CONFIG("Config", false, false),
    @SerializedName("Theme")
    THEME("Theme", true, true),
    @SerializedName("Addon")
    ADDON("Addon", true, true),

    /**
     * Installed like any item; the ScriptAPI add-on runs them through [MarketplaceManager.registerHandler].
     */
    @SerializedName("Script")
    SCRIPT("Script", true, true),
    @SerializedName("Other")
    OTHER("Other", false, false);

    suspend fun reload() = when (this) {
        THEME -> ThemeManager.load()
        ADDON -> AddonInstaller.stageSubscribedAddons()
        else -> MarketplaceManager.reloadHandled(this)
    }
}
