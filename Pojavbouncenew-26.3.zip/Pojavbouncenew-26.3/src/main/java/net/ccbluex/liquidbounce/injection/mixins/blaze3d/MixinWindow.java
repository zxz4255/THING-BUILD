/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2026 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.injection.mixins.blaze3d;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.platform.IconSet;
import com.mojang.blaze3d.platform.Window;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventManager;
import net.ccbluex.liquidbounce.event.events.FramebufferResizeEvent;
import net.ccbluex.liquidbounce.event.events.ScaleFactorChangeEvent;
import net.ccbluex.liquidbounce.event.events.WindowResizeEvent;
import net.ccbluex.liquidbounce.features.misc.SelfDestruct;
import net.minecraft.server.packs.PackMetadataResources;
import net.minecraft.server.packs.resources.IoSupplier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.InputStream;
import java.util.List;

@Mixin(Window.class)
public abstract class MixinWindow {

    /**
     * Set the window icon to our client icon.
     *
     * @return modified game icon
     */
    @WrapOperation(method = "setIcon(Lnet/minecraft/server/packs/PackMetadataResources;Lcom/mojang/blaze3d/platform/IconSet;)V", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/IconSet;getStandardIcons(Lnet/minecraft/server/packs/PackMetadataResources;)Ljava/util/List;"))
    private List<IoSupplier<InputStream>> setupIcon(IconSet instance, PackMetadataResources resources, Operation<List<IoSupplier<InputStream>>> original) {
        if (SelfDestruct.INSTANCE.isDestructed()) {
            return original.call(instance, resources);
        }

        LiquidBounce.INSTANCE.getLogger().debug("Loading client icons");

        // Find client icons
        final InputStream stream16 = LiquidBounce.class.getResourceAsStream("/resources/liquidbounce/icon_16x16.png");
        final InputStream stream32 = LiquidBounce.class.getResourceAsStream("/resources/liquidbounce/icon_32x32.png");

        // In case one of the icons was not found
        if (stream16 == null || stream32 == null) {
            LiquidBounce.INSTANCE.getLogger().error("Unable to find client icons.");

            // Load default icons
            return original.call(instance, resources);
        }

        return List.of(() -> stream16, () -> stream32);
    }

    /**
     * Hook window resize
     */
    @Inject(method = "onResize", at = @At("RETURN"))
    public void hookResize(int newWidth, int newHeight, CallbackInfo ci) {
        EventManager.INSTANCE.callEvent(new WindowResizeEvent(newWidth, newHeight));
    }

    @Inject(method = "onFramebufferResize", at = @At("RETURN"))
    public void hookFramebufferResize(int newWidth, int newHeight, CallbackInfo ci) {
        EventManager.INSTANCE.callEvent(new FramebufferResizeEvent(newWidth, newHeight));
    }

    @Inject(method = "setGuiScale", at = @At("RETURN"))
    public void hookScaleFactor(int scaleFactor, CallbackInfo ci) {
        EventManager.INSTANCE.callEvent(new ScaleFactorChangeEvent(scaleFactor));
    }

}
